import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class pdet extends JFrame{

	JPanel p1=new JPanel();
	JButton b1=new JButton("Create New Patient");
	JButton b2=new JButton("View Patient Details");
	JButton b3=new JButton("Back");
	JLabel l1=new JLabel();
	String user;
	public pdet(String s2) {
		// TODO Auto-generated constructor stub
	super("Patient Details");
	p1.setLayout(null);
	user=s2;
	l1.setText("Welcome "+s2);
	ButtonHandler l=new ButtonHandler();
	b1.setBounds(500, 60, 300, 40);
	b2.setBounds(500, 140, 300, 40);
	b3.setBounds(100, 20, 100, 30);
	l1.setBounds(1000,20,150,30);
	b1.addActionListener(l);
	b2.addActionListener(l);
	b3.addActionListener(l);
	p1.add(l1);
	p1.add(b1);
	p1.add(b2);
	p1.add(b3);
	getContentPane().add(p1);
	}

	private class ButtonHandler implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource()==b1)
			{
				 cp pw = new cp(user); // create ButtonFrame
				 pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
				 Toolkit tk=Toolkit.getDefaultToolkit();
				 pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
				 pw.setVisible(true);
				 setVisible(false);
			}
			if(e.getSource()==b2)
			{
				 vpd pw = new vpd(user); // create ButtonFrame
				 pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
				 Toolkit tk=Toolkit.getDefaultToolkit();
				 pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
				 pw.setVisible(true);
				 setVisible(false);
			}
			if(e.getSource()==b3)
			{
				 doit pw = new doit(user); // create ButtonFrame
				 pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
				 Toolkit tk=Toolkit.getDefaultToolkit();
				 pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
				 pw.setVisible(true);
				 setVisible(false);
			}
		}
	}
}
