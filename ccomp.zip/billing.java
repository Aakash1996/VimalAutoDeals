import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.jdesktop.swingx.JXDatePicker;


public class billing extends JFrame{

	
	Statement stm=null;
	gcon k=new gcon();
	//Connection d=k.getDBConnection();
	Connection d;
	JPanel p1=new JPanel();
	JLabel l0=new JLabel();
	JLabel l1=new JLabel("Date");
	JLabel l2=new JLabel("Bill NO");
	JLabel l3=new JLabel("Name");
	JXDatePicker t1=new JXDatePicker();
	JTextField t2=new JTextField();
	JTextField t3=new JTextField();
	JLabel l4=new JLabel("1");
	JLabel l5=new JLabel("2");
	JLabel l6=new JLabel("3");
	JLabel l7=new JLabel("4");
	JLabel l8=new JLabel("5");
	JLabel l9=new JLabel("S.NO");
	JLabel l10=new JLabel("Product");
	JLabel l11=new JLabel("Price Inclusive of VAT");
	JLabel l12=new JLabel("VAT ");
	JLabel l13=new JLabel("TOTAl");
	JLabel l14=new JLabel();
	JLabel l15=new JLabel();
	JComboBox t4;
	JComboBox t5;
	JComboBox t6;
	JComboBox t7;
	JComboBox t8;
	JTextField t41=new JTextField();
	JTextField t51=new JTextField();
	JTextField t61=new JTextField();
	JTextField t71=new JTextField();
	JTextField t81=new JTextField();
	JTextField q41=new JTextField();
	JTextField q51=new JTextField();
	JTextField q61=new JTextField();
	JTextField q71=new JTextField();
	JTextField q81=new JTextField();
	JButton b1=new JButton("Save");
	JButton b2=new JButton("Save & Print");
	JButton b3=new JButton("Discard And Go Back");
	JButton b4=new JButton("Add");
	JButton b5=new JButton("Add");
	JButton b6=new JButton("Add");
	JButton b7=new JButton("Add");
	JButton b8=new JButton("Add");
	JButton b9=new JButton("Generate Total");
	String user=null;
	String ar[]={"Frame + Lens","Sunglasses","Contact Lens","Lens Solution"};
	String cbillno1=null;
	String cname1=null;
	Date d2=null;
	int c41,c51,c61,c71,c81;
	String ct41,ct51,ct61,ct71,ct81;
	String id1,id2,id3,id4,id5;
	public billing(String s2,Date d1,String bllno,String bname,int c4,int c5,int c6,int c7,int c8,String ct4,String ct5,String ct6,String ct7,String ct8,String ct9,String ct10,String ct11,String ct12,String ct13,Connection f) {
		// TODO Auto-generated constructor stub
		/*try {
			d.setAutoCommit(false);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		d=f;
		if(ct4.equals("null")&&ct5.equals("null")&&ct6.equals("null")&&ct7.equals("null")&&ct8.equals("null"))
		{
			try
			{
				String sql="SAVEPOINT beforebill";
				//System.out.println(sql);
				stm=d.createStatement();
				stm.executeUpdate(sql);
				//System.out.println("sql");
				
			}
			catch(SQLException fe)
			{
				JOptionPane.showMessageDialog(null,"Savepoint Failed");
				//fe.printStackTrace();
			}
		}
		c41=c4;
		c51=c5;
		c61=c6;
		c71=c7;
		c81=c8;
		ct41=ct4;
		ct51=ct5;
		ct61=ct6;
		ct71=ct7;
		ct81=ct8;
		id1=ct9;
		id2=ct10;
		id3=ct11;
		id4=ct12;
		id5=ct13;
		
		cbillno1=bllno;
		cname1=bname;
		d2=d1;
		p1.setLayout(null);
		user=s2;
		if(cbillno1.equals("null"))
		{
			int ne=0;
			try
			{
				 
				//d=k.getDBConnection();
				
				String sql="Select max(BILLNO) as count from billentry";
			 stm=d.createStatement();
			 ResultSet rs=stm.executeQuery(sql);
				while(rs.next())
				{
					if(rs.getString("count") != null)
					ne = Integer.parseInt(rs.getString("count"));
				}
			}
			catch(SQLException fe)
			{
				fe.printStackTrace();
			}
			ne++;
			t2.setText(Integer.toString(ne));
		}
		else 
		t2.setText(cbillno1);
		t3.setText(cname1);
		t4=new JComboBox(ar);
		t5=new JComboBox(ar);
		t6=new JComboBox(ar);
		t7=new JComboBox(ar);
		t8=new JComboBox(ar);
		t41.setText(ct4);q41.setText(id1);
		t51.setText(ct5);q51.setText(id2);
		t61.setText(ct6);q61.setText(id3);
		t71.setText(ct7);q71.setText(id4);
		t81.setText(ct8);q81.setText(id5);
		FocusListener fo= new FocusAdapter() {
			  public void focusGained(FocusEvent fEvt) {
				    JTextField tField = (JTextField)fEvt.getSource();
				    tField.selectAll();
				  }
				};
		t2.addFocusListener(fo);
		t3.addFocusListener(fo);
		//t2.setFocusable(isFocusable());
		//tf3=new JComboBox(ar);
		l0.setText("Welcome "+s2);
		t1.setDate(d1);
		t4.setSelectedIndex(c4);
		t5.setSelectedIndex(c5);
		t6.setSelectedIndex(c6);
		t7.setSelectedIndex(c7);
		t8.setSelectedIndex(c8);
		t1.setFormats(new SimpleDateFormat("dd.MMM.yyyy"));
		l0.setBounds(1100, 20, 120, 30);
		l1.setBounds(100,60,150,40);
		t1.setBounds(300,60,150,40);
		l2.setBounds(900,60,150,40);
		t2.setBounds(1100,60,150,40);
		l3.setBounds(100,120,150,40);
		t3.setBounds(300,120,300,40);
		l9.setBounds(50, 170, 50, 30);
		l10.setBounds(200, 170, 150, 30);
		//b4.setBounds(450, 170, 100, 30);
		l11.setBounds(650, 170, 150, 30);
		l4.setBounds(50, 220, 50, 30);
		t4.setBounds(200, 220, 150, 30);
		b4.setBounds(450, 220, 100, 30);
		t41.setBounds(650, 220, 150, 30);
		q41.setBounds(850, 220, 150, 30);
		l5.setBounds(50, 270, 50, 30);
		t5.setBounds(200, 270, 150, 30);
		b5.setBounds(450, 270, 100, 30);
		t51.setBounds(650, 270, 150, 30);
		q51.setBounds(850, 270, 150, 30);
		l6.setBounds(50, 320, 50, 30);
		t6.setBounds(200, 320, 150, 30);
		b6.setBounds(450, 320, 100, 30);
		t61.setBounds(650, 320, 150, 30);
		q61.setBounds(850, 320, 150, 30);
		l7.setBounds(50, 370, 50, 30);
		t7.setBounds(200, 370, 150, 30);
		b7.setBounds(450, 370, 100, 30);
		t71.setBounds(650, 370, 150, 30);
		q71.setBounds(850, 370, 150, 30);
		l8.setBounds(50, 420, 50, 30);
		t8.setBounds(200, 420, 150, 30);
		b8.setBounds(450, 420, 100, 30);
		t81.setBounds(650, 420, 150, 30);
		q81.setBounds(850, 420, 150, 30);
		l12.setBounds(500, 480, 100, 30);
		l14.setBounds(700, 480, 100, 30);
		l13.setBounds(500, 530, 100, 30);
		l15.setBounds(700, 530, 100, 30);
		b9.setBounds(950, 490, 150, 30);
		b1.setBounds(300, 620, 200, 30);
		b2.setBounds(600, 620, 200, 30);
		b3.setBounds(900, 620, 200, 30);
		q41.setEditable(false);q51.setEditable(false);q61.setEditable(false);q71.setEditable(false);q81.setEditable(false);
		ButtonHandler l=new ButtonHandler();
		b4.addActionListener(l);
		b5.addActionListener(l);
		b6.addActionListener(l);
		b7.addActionListener(l);
		b8.addActionListener(l);
		b9.addActionListener(l);b3.addActionListener(l);b2.addActionListener(l);b1.addActionListener(l);
		p1.add(b9);p1.add(l12);p1.add(l13);p1.add(l14);p1.add(l15);p1.add(q41);p1.add(q51);p1.add(q61);p1.add(q71);p1.add(q81);
		//b4.addActionListener(l);
		//t41.setText(t411);
		//t51.setText(t511);
		//t61.setText(t611);
		//t71.setText(t711);
		//t81.setText(t811);
		p1.add(l0);
		p1.add(l1);
		p1.add(l2);
		p1.add(l3);
		p1.add(l4);
		p1.add(l5);
		p1.add(l6);
		p1.add(l7);
		p1.add(l8);
		p1.add(l9);
		p1.add(l10);
		p1.add(l11);
		p1.add(t1);
		p1.add(t2);
		p1.add(t3);
		p1.add(t4);
		p1.add(t5);
		p1.add(t6);
		p1.add(t7);
		p1.add(t8);
		p1.add(t41);
		p1.add(t51);
		p1.add(t61);
		p1.add(t71);
		p1.add(t81);
		p1.add(b1);
		p1.add(b2);
		p1.add(b3);
		p1.add(b4);
		p1.add(b5);
		p1.add(b6);
		p1.add(b7);
		p1.add(b8);
		getContentPane().add(p1);
		}

	private class ButtonHandler implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			/*Date d1=null;
			String name=null;
			
			String btnno=null;
			*/
			String btnno=null;
			d2=t1.getDate();
			cname1=t3.getText();
			cbillno1=t2.getText();
			c41=t4.getSelectedIndex();
			c51=t5.getSelectedIndex();
			c61=t6.getSelectedIndex();
			c71=t7.getSelectedIndex();
			c81=t8.getSelectedIndex();
			ct41=t41.getText();
			ct51=t51.getText();
			ct61=t61.getText();
			ct71=t71.getText();
			ct81=t81.getText();
			id1=q41.getText();id2=q51.getText();id3=q61.getText();id4=q71.getText();id5=q81.getText();
			//String op=null;
			if(e.getSource()==b4||e.getSource()==b5||e.getSource()==b6||e.getSource()==b7||e.getSource()==b8)
			{
			if(e.getSource()==b4)
			{
				btnno="4";
				if(c41==0)
				{
					pfl pw = new pfl(user,d2,cbillno1,cname1,c41,c51,c61,c71,c81,ct41,ct51,ct61,ct71,ct81,btnno,id1,id2,id3,id4,id5,d);
					pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					Toolkit tk=Toolkit.getDefaultToolkit();
					pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
					pw.setVisible(true);
					setVisible(false);
				}
				if(c41==1||c41==3||c41==2)
				{
					String op=null;
					if(c41==1)
						op="sunglasses";
					if(c41==2)
						op="contact lens";
					if(c41==3)
						op="solution";
					ssun1 pw = new ssun1(user,d2,cbillno1,cname1,c41,c51,c61,c71,c81,ct41,ct51,ct61,ct71,ct81,btnno,op,id1,id2,id3,id4,id5,d);
					pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					Toolkit tk=Toolkit.getDefaultToolkit();
					pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
					pw.setVisible(true);
					setVisible(false);
				}
				
			}
			if(e.getSource()==b5)
			{
				btnno="5";
				if(c51==0)
				{
					pfl pw = new pfl(user,d2,cbillno1,cname1,c41,c51,c61,c71,c81,ct41,ct51,ct61,ct71,ct81,btnno,id1,id2,id3,id4,id5,d);
					pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					Toolkit tk=Toolkit.getDefaultToolkit();
					pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
					pw.setVisible(true);
					setVisible(false);
				}
				if(c51==1||c51==3||c51==2)
				{
					String op=null;
					if(c51==1)
						op="sunglasses";
					if(c51==2)
						op="contact lens";
					if(c51==3)
						op="solution";
					ssun1 pw = new ssun1(user,d2,cbillno1,cname1,c41,c51,c61,c71,c81,ct41,ct51,ct61,ct71,ct81,btnno,op,id1,id2,id3,id4,id5,d);
					pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					Toolkit tk=Toolkit.getDefaultToolkit();
					pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
					pw.setVisible(true);
					setVisible(false);
				}
			}
			if(e.getSource()==b6)
			{
				btnno="6";
				if(c61==0)
				{
					pfl pw = new pfl(user,d2,cbillno1,cname1,c41,c51,c61,c71,c81,ct41,ct51,ct61,ct71,ct81,btnno,id1,id2,id3,id4,id5,d);
					pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					Toolkit tk=Toolkit.getDefaultToolkit();
					pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
					pw.setVisible(true);
					setVisible(false);
				}
				if(c61==1||c61==3||c61==2)
				{
					String op=null;
					if(c61==1)
						op="sunglasses";
					if(c61==2)
						op="contact lens";
					if(c61==3)
						op="solution";
					ssun1 pw = new ssun1(user,d2,cbillno1,cname1,c41,c51,c61,c71,c81,ct41,ct51,ct61,ct71,ct81,btnno,op,id1,id2,id3,id4,id5,d);
					pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					Toolkit tk=Toolkit.getDefaultToolkit();
					pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
					pw.setVisible(true);
					setVisible(false);
				}
			}
			if(e.getSource()==b7)
			{
				btnno="7";
				if(c71==0)
				{
					pfl pw = new pfl(user,d2,cbillno1,cname1,c41,c51,c61,c71,c81,ct41,ct51,ct61,ct71,ct81,btnno,id1,id2,id3,id4,id5,d);
					pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					Toolkit tk=Toolkit.getDefaultToolkit();
					pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
					pw.setVisible(true);
					setVisible(false);
				}
				if(c71==1||c71==3||c71==2)
				{
					String op=null;
					if(c71==1)
						op="sunglasses";
					if(c71==2)
						op="contact lens";
					if(c71==3)
						op="solution";
					ssun1 pw = new ssun1(user,d2,cbillno1,cname1,c41,c51,c61,c71,c81,ct41,ct51,ct61,ct71,ct81,btnno,op,id1,id2,id3,id4,id5,d);
					pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					Toolkit tk=Toolkit.getDefaultToolkit();
					pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
					pw.setVisible(true);
					setVisible(false);
				}
			}
			if(e.getSource()==b8)
			{
				btnno="8";
				if(c81==0)
				{
					pfl pw = new pfl(user,d2,cbillno1,cname1,c41,c51,c61,c71,c81,ct41,ct51,ct61,ct71,ct81,btnno,id1,id2,id3,id4,id5,d);
					pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					Toolkit tk=Toolkit.getDefaultToolkit();
					pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
					pw.setVisible(true);
					setVisible(false);
				}
				if(c81==1||c81==3||c81==2)
				{
					String op=null;
					if(c81==1)
						op="sunglasses";
					if(c81==2)
						op="contact lens";
					if(c81==3)
						op="solution";
					ssun1 pw = new ssun1(user,d2,cbillno1,cname1,c41,c51,c61,c71,c81,ct41,ct51,ct61,ct71,ct81,btnno,op,id1,id2,id3,id4,id5,d);
					pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					Toolkit tk=Toolkit.getDefaultToolkit();
					pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
					pw.setVisible(true);
					setVisible(false);
				}
			}
			
			/*if(op=="Frame + Lens")
			{
				pfl pw = new pfl(user);
				pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
				Toolkit tk=Toolkit.getDefaultToolkit();
				pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
				pw.setVisible(true);
			}
			*/
			//if(op=="Sunglasses")
			//if(op=="Contact Lens")
			
				//setVisible(false);
		}
			if(e.getSource()==b9)
			{
				String s1=t41.getText(),s2=t51.getText(),s3=t61.getText(),s4=t71.getText(),s5=t81.getText();
				int total=0;
				double vat=0;
				//System.out.println(s1+s2+s3+s4+s5);
				if(!s1.equals("null"))
					{
					//System.out.println(s1);
					total+=Integer.parseInt(s1);
					}
				if(!(s2.equals("null")))
					{
					//System.out.println(s2+"in s22222  22");
					total+=Integer.parseInt(s2);
					}
				if(!s3.equals("null"))
					total+=Integer.parseInt(s3);
				if(!s4.equals("null"))
					total+=Integer.parseInt(s4);
				if(!s5.equals("null"))
					total+=Integer.parseInt(s5);
				vat= (total*0.05);
				String tt=String.valueOf(total)+" in the b9   "+String.valueOf(vat);
				//System.out.println(tt);
				l14.setText(String.valueOf(vat));
				l15.setText(String.valueOf(total));
			}
			if(e.getSource()==b1||e.getSource()==b2)
			{
				
				String r1=t41.getText(),r2=t51.getText(),r3=t61.getText(),r4=t71.getText(),r5=t81.getText();
				int total2=0;
				double vat2=0;
				//System.out.println(s1+s2+s3+s4+s5);
				if(!r1.equals("null"))
					{
					//System.out.println(s1);
					total2+=Integer.parseInt(r1);
					}
				if(!(r2.equals("null")))
					{
					//System.out.println(s2+"in s22222  22");
					total2+=Integer.parseInt(r2);
					}
				if(!r3.equals("null"))
					total2+=Integer.parseInt(r3);
				if(!r4.equals("null"))
					total2+=Integer.parseInt(r4);
				if(!r5.equals("null"))
					total2+=Integer.parseInt(r5);
				vat2= (total2*0.05);
				//String tt=String.valueOf(total2)+" in the b9   "+String.valueOf(vat);
				//System.out.println(tt);
				l14.setText(String.valueOf(vat2));
				l15.setText(String.valueOf(total2));
				//d=k.getDBConnection();
				Date s1=t1.getDate();
				if(s1==null)
					s1=Calendar.getInstance().getTime();
				//System.out.println(s1);
				//System.out.println(s1);
				SimpleDateFormat sdf=new SimpleDateFormat("dd.MMM.yyyy");
				String b8=sdf.format(s1);
				String s2=t2.getText();
				String s3=t3.getText();
				String s41=q41.getText();
				String s51=q51.getText();
				String s61=q61.getText();
				String s71=q71.getText();
				String s81=q81.getText();
				String s9=l14.getText();
				String s10=l15.getText();
				String s4=(String)t4.getSelectedItem();
				String s5=(String)t5.getSelectedItem();
				String s6=(String)t6.getSelectedItem();
				String s7=(String)t7.getSelectedItem();
				String s8=(String)t8.getSelectedItem();
				String j41=t41.getText();
				String j51=t51.getText();
				String j61=t61.getText();
				String j71=t71.getText();
				String j81=t81.getText();
				if(s41.equals("null"))
					{
					s4="null";
					}
				if(s51.equals("null"))
					{s5="null";}
				if(s61.equals("null"))
					{s6="null";}
				if(s71.equals("null"))
					{s7="null";}
				if(s81.equals("null"))
					{s8="null";}
				try
				{
					String sql="insert into billentry values('"+b8+"',"+s2+",'"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"','"+s8+"',"+s9+","+s10+",'"+s41+"','"+s51+"','"+s61+"','"+s71+"','"+s81+"')";
					//System.out.println(sql);
					stm=d.createStatement();
					stm.executeUpdate(sql);
					//System.out.println("sql");
					sql="Commit";
					stm=d.createStatement();
					stm.executeUpdate(sql);
					doit pw = new doit(user);
					pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					Toolkit tk=Toolkit.getDefaultToolkit();
					pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
					pw.setVisible(true);
					setVisible(false);
					if(e.getSource()==b2)
					{
						printingtemplatebill example2 = new printingtemplatebill(b8,s2,s3,s4,j41,s5,j51,s6,j61,s7,j71,s8,j81,s9,s10);	
					}
				}
				catch(SQLException fe)
				{
					JOptionPane.showMessageDialog(null,"Generate Total");
					//fe.printStackTrace();
				}
				//System.out.println("DOneeeeeeeeeeee");
				/*try {
					d.commit();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}*/
			}
			
			if(e.getSource()==b3)
			{
				//d=k.getDBConnection();
				/*try
				{
					String sql="SAVEPOINT beforebill";
					//System.out.println(sql);
					stm=d.createStatement();
					stm.executeUpdate(sql);
					//System.out.println("sql");
					
				}
				catch(SQLException fe)
				{
					JOptionPane.showMessageDialog(null,"Savepoint Failed");
					fe.printStackTrace();
				}*/
				try
				{
					String sql="ROLLBACK TO beforebill";
					//System.out.println(sql);
					stm=d.createStatement();
					stm.executeUpdate(sql);
					d.close();
					//System.out.println("sql");
					doit pw = new doit(user);
					pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
					Toolkit tk=Toolkit.getDefaultToolkit();
					pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
					pw.setVisible(true);
					setVisible(false);
				}
				catch(SQLException fe)
				{
					JOptionPane.showMessageDialog(null,"RollBack Failed");
					fe.printStackTrace();
				}
				
			}
		}
		
	}
	void settf4(String to1)
	{
		t41.setText(to1);
	}
}
