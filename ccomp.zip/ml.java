import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class ml extends JFrame{

	JPanel p1=new JPanel();
	JButton b1=new JButton("Make Payment Entry");
	JButton b2=new JButton("View Ledger");
	JButton b3=new JButton("Back");
	String s1;
	JLabel l1=new JLabel();
	public ml(String s2) {
		// TODO Auto-generated constructor stub
		p1.setLayout(null);
		ButtonHandler l=new ButtonHandler();
		b1.addActionListener(l);
		b2.addActionListener(l);
		b3.addActionListener(l);
		s1=s2;
		l1.setText("Welcome "+s1);
		l1.setBounds(1100, 20, 120, 20);
		b3.setBounds(100, 20, 100, 30);
		b1.setBounds(500,60,300,40);
		b2.setBounds(500,120,300,40);
		p1.add(l1);
		p1.add(b1);
		p1.add(b2);
		p1.add(b3);
		getContentPane().add(p1);
		
	}
private class ButtonHandler implements ActionListener
{

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==b1)
		{
			 mpe pw = new mpe(s1); // create ButtonFrame
			 pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
			 Toolkit tk=Toolkit.getDefaultToolkit();
			 pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
			 pw.setVisible(true);
			 setVisible(false);
		}
		if(e.getSource()==b2)
		{
			 vl pw = new vl(s1); // create ButtonFrame
			 pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
			 Toolkit tk=Toolkit.getDefaultToolkit();
			 pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
			 pw.setVisible(true);
			 setVisible(false);
		}
		if(e.getSource()==b3)
		{
			doit pw = new doit(s1); // create ButtonFrame
			 pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
			 Toolkit tk=Toolkit.getDefaultToolkit();
			 pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
			 pw.setVisible(true);
			 setVisible(false);
		}
	}
	
}
}
