import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class cp extends JFrame{

	JPanel p1=new JPanel();
	JLabel l0=new JLabel();
	JLabel l1=new JLabel("CID");
	JLabel l2=new JLabel("Name");
	JLabel l3=new JLabel("Address");
	JLabel l4=new JLabel("Prescription");
	JTextField t1=new JTextField();
	JTextField t2=new JTextField();
	JTextField t3=new JTextField();
	JTextField t4=new JTextField();
	JButton b1=new JButton("Back");
	JButton b2=new JButton("Add Presciption Browse");
	JButton b3=new JButton("OK");
	String user1;
	
	Statement stm=null;
	gcon k=new gcon();
	Connection d=k.getDBConnection();
	//JFileChooser fileChooser;
	
	public cp(String user) {
		// TODO Auto-generated constructor stub
		super("Create patient");
		l0.setText("Welcome "+user);
		int ne=0;
		user1=user;
		p1.setLayout(null);
		try
		{
			
			String sql="Select max(cid) as count from pdet";
		 stm=d.createStatement();
			ResultSet rs=stm.executeQuery(sql);
			while(rs.next())
			{
				if(rs.getString("count") != null)
				ne = Integer.parseInt(rs.getString("count"));
			}
		}
		catch(SQLException fe)
		{
			fe.printStackTrace();
		}
		ne++;
		t4.setText("null");
		t1.setText(Integer.toString(ne));
		t1.setEditable(false);
		l0.setBounds(1000, 20, 150, 30);
		b1.setBounds(100, 20, 150, 30);
		l1.setBounds(400, 80, 200, 40);
		t1.setBounds(700, 80, 200, 40);
		l2.setBounds(400, 150, 200, 40);
		t2.setBounds(700, 150, 200, 40);
		l3.setBounds(400, 220, 200, 40);
		t3.setBounds(700, 220, 200, 40);
		l4.setBounds(400, 290, 200, 40);
		t4.setBounds(700, 290, 200, 40);
		b2.setBounds(1000, 295, 250, 30);
		b3.setBounds(650, 380, 150, 40);
		ButtonHandler l= new ButtonHandler();
		b1.addActionListener(l);
		b2.addActionListener(l);
		b3.addActionListener(l);
		p1.add(l0);p1.add(l1);p1.add(l2);p1.add(l3);p1.add(l4);p1.add(t1);p1.add(t2);p1.add(t3);p1.add(t4);p1.add(b1);p1.add(b2);p1.add(b3);
		/*fileChooser = new JFileChooser();
		fileChooser.setControlButtonsAreShown(false);
	    getContentPane().add(fileChooser, BorderLayout.CENTER);
		fileChooser.setDialogTitle("Choose a file");
	    *///getContentPane().add(fileChooser);
		getContentPane().add(p1);
	}
private class ButtonHandler implements ActionListener
{

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==b1)
		{
			try {
				d.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			pdet pw = new pdet(user1); // create ButtonFrame
			 pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
			 Toolkit tk=Toolkit.getDefaultToolkit();
			 pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
			 pw.setVisible(true);
			 setVisible(false);
		}
		if(e.getSource()==b2)
		{
			String filePath="null"; 
			JFileChooser fileChooser = new JFileChooser();
		        int returnValue = fileChooser.showOpenDialog(null);
		        if (returnValue == JFileChooser.APPROVE_OPTION) {
		        	filePath = fileChooser.getSelectedFile().getAbsolutePath();
		        	//File selectedFile = fileChooser.getSelectedFile();
		          //System.out.println(filePath);
		        }
		        t4.setText(filePath);
		}
		if(e.getSource()==b3)
		{
			//Date s1=tf1.getDate();
			//System.out.println(s1);
			//SimpleDateFormat sdf=new SimpleDateFormat("dd.MMM.yyyy");
			//String b8=sdf.format(s1);
			//System.out.println(b8);
			String s1=t1.getText();
			//String s2=(String)t.getSelectedItem();
			String s2=t2.getText();
			String s3=t3.getText();
			String s4=t4.getText();
			//String s7=tf7.getText();
			//String s8=tf8.getText();
			//int pid=Integer.parseInt(s2);
			//int cp=Integer.parseInt(s5);
			try
			{
				String sql="insert into pdet values("+s1+",'"+s2+"','"+s3+"','"+s4+"')";
				//System.out.println(sql);
				stm=d.createStatement();
				stm.executeUpdate(sql);
				d.close();
				pdet pw = new pdet(user1); // create ButtonFrame
				 pw.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
				 Toolkit tk=Toolkit.getDefaultToolkit();
				 pw.setSize( (int) tk.getScreenSize().getWidth(),(int) tk.getScreenSize().getHeight()); // set frame size
				 pw.setVisible(true);
				setVisible(false);
			}
			catch(SQLException fe)
			{
				JOptionPane.showMessageDialog(null,"Fill All Fields and Try Again");
				//fe.printStackTrace();
			}
	
		}
	}
	
}
}
